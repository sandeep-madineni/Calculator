//
//  Calculator.h
//  Calculator
//
//  Created by Sandeep Madineni on 10/02/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Calculator.
FOUNDATION_EXPORT double CalculatorVersionNumber;

//! Project version string for Calculator.
FOUNDATION_EXPORT const unsigned char CalculatorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Calculator/PublicHeader.h>


