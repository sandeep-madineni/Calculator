//
//  CalculatorOperations.h
//  Calculator
//
//  Created by Sandeep Madineni on 10/02/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CalculatorOperations : NSObject

-(int)add:(int)a with:(int)b;

@end

NS_ASSUME_NONNULL_END
